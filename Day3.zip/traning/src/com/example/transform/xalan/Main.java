package com.example.transform.xalan;

import java.io.FileWriter;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

public class Main {

	private static String XML_FILE = "files/cars.xml";
	//private static String XSL_FILE = "files/cars-1.xsl";
	private static String XSL_FILE = "files/cars-2.xsl";
	

	public static void main(String[] args) throws Exception {
		// tranformAndWriteToConsole();
		//tranformAndWriteToHTMLFile();
		tranformAndWriteToXmlFile();
		System.out.println("Finished!!");
	}

	private static void tranformAndWriteToXmlFile() throws Exception {

		String HTML_FILE = "files/cars-sales.xml";
		FileWriter fileWriter = new FileWriter(HTML_FILE);
		
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer(new StreamSource(XSL_FILE));
		transformer.transform(new StreamSource(XML_FILE), new StreamResult(fileWriter));

		fileWriter.close();
		
	}

	private static void tranformAndWriteToHTMLFile() throws Exception {

		String HTML_FILE = "files/cars.html";
		FileWriter fileWriter = new FileWriter(HTML_FILE);
		
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer(new StreamSource(XSL_FILE));
		transformer.transform(new StreamSource(XML_FILE), new StreamResult(fileWriter));

		fileWriter.close();
		
	}

	private static void tranformAndWriteToConsole() throws Exception {

		// Step 1 - Initialize Transformer Factory
		// TransformerFactory transformerFactory = TransformerFactory.newInstance();
		TransformerFactory transformerFactory = TransformerFactory
				.newInstance("org.apache.xalan.processor.TransformerFactoryImpl", null);
		System.out.println(transformerFactory);

		// Step 2 - Initialize Transformer
		Transformer transformer = transformerFactory.newTransformer(new StreamSource(XSL_FILE));

		// Step 3 - Do Transformation and Display Transformation result
		transformer.transform(new StreamSource(XML_FILE), new StreamResult(System.out));

	}

}
