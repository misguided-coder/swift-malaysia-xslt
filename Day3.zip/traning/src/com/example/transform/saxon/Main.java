package com.example.transform.saxon;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

public class Main {

	private static String XML_FILE = "files/cars.xml";
	private static String XSL_FILE = "files/cars.xsl";

	public static void main(String[] args) throws Exception {

		//TransformerFactory transformerFactory = TransformerFactory.newInstance();
		TransformerFactory transformerFactory = TransformerFactory.newInstance("net.sf.saxon.TransformerFactoryImpl",null);
		System.out.println(transformerFactory);

		Transformer transformer = transformerFactory.newTransformer(new StreamSource(XSL_FILE));

		transformer.transform(new StreamSource(XML_FILE), new StreamResult(System.out));
		System.out.println("Finished!!");

	}

}
