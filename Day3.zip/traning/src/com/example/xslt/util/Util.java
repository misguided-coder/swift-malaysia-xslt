package com.example.xslt.util;

import java.time.LocalDate;
import java.time.LocalTime;

public class Util {

	public static String convertToUpper(String value) {
		System.out.println("INFO --- Inside Util.convertToUpper()!!");
		return value.toUpperCase();
	}

	public static String currentDate() {
		System.out.println("INFO --- Inside Util.currentDate()!!");
		LocalDate localDate = LocalDate.now();
		return localDate.toString();
	}

	public static String currentTime() {
		System.out.println("INFO --- Inside Util.currentTime()!!");
		LocalTime localTime = LocalTime.now();
		return localTime.toString();
	}
}
