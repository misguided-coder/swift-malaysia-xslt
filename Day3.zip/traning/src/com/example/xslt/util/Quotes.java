package com.example.xslt.util;

public class Quotes {

	static String quotes[] = { "Mondays are little boring.", "Mondays are always welcome.",
			"Life is a one time offer, just live it." };

	public static String next() {
		System.out.println("INFO --- Inside Util.next()!!");
		int idx = (int) (Math.random() * quotes.length);
		return quotes[idx];
	}
}
