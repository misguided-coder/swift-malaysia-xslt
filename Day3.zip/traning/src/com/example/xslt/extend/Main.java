package com.example.xslt.extend;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

public class Main {

	private static String XML_FILE = "files/cars.xml";
	private static String XSL_FILE = "files/cars.xsl";

	public static void main(String[] args) throws Exception {

		TransformerFactory transformerFactory = TransformerFactory.newInstance();

		Transformer transformer = transformerFactory.newTransformer(new StreamSource(XSL_FILE));

		transformer.transform(new StreamSource(XML_FILE), new StreamResult(System.out));

	}

}
