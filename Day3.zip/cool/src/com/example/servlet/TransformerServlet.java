package com.example.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

public class TransformerServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("INFO -------- Inside TransformerServlet doGet()!!");

		response.setContentType("text/html");

		String TRANSFORM_RULE = getServletConfig().getInitParameter("TRANSFORM_RULE");

		String appPath = request.getServletContext().getRealPath("");
		String XML_FILE = appPath + "data/cars.xml";

		String XSL_FILE = appPath;

		if (TRANSFORM_RULE.equals("tabular")) {
			XSL_FILE = XSL_FILE + "data/cars-tabular.xsl";
		} else {
			XSL_FILE = XSL_FILE + "data/cars.xsl";
		}

		PrintWriter printWriter = response.getWriter();

		TransformerFactory transformerFactory = TransformerFactory.newInstance();

		try {
			Transformer transformer = transformerFactory.newTransformer(new StreamSource(XSL_FILE));
			transformer.transform(new StreamSource(XML_FILE), new StreamResult(printWriter));
		} catch (TransformerConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		}

	}

}
